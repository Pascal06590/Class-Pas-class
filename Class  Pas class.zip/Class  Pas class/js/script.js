$(window).on("load", function(){
	$(".rond").each(function(){
		$(this).on("click", function(){
			$(this).toggleClass('full');
		});
	});

	$(".carr").each(function(){
		$(this).on("click", function(){
			var classList = $(this).attr('class').split(/\s+/);
			console.log(classList[2]);
			if($(this).hasClass("full")){
				$("."+classList[2]).removeClass("full");
			} else {
				$("."+classList[2]).addClass("full");
			}
		});
	});

	$(".losa").each(function(){
		$(this).on("click", function(){
			var classList = $(this).attr('class').split(/\s+/);
			if($(this).hasClass("full")){
				$("."+classList[2]+", ."+classList[1]).removeClass("full");
			} else {
				$("."+classList[2]+", ."+classList[1]).addClass("full");
			}
		});
	});

	$("#Remplir").on("click", function(){
		$("#AppelFonction div").addClass("full");
	});
	$("#Vider").on("click", function(){
		$("#AppelFonction div").removeClass("full");
	});
});
